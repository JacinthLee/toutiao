package com.nowcoder.model;

/**
 * Created by Jacinth on 2017/3/21.
 */
public class EntityType {
    public static int ENTITY_NEWS=1;
    public static int ENTITY_COMMENT=2;
}
